package org.symantec.metrics.dashboard;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileStatus;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;

public class idcstats
{

	public Map<String,String> getIDCStats(String path,boolean flag) throws IOException, URISyntaxException
	{
		System.out.println("hai");
		Map <String,String> idc=new HashMap<String,String>();
		
		Path p1 = new Path(
				path);
		Configuration conf = new Configuration();
		//conf.addResource(new Path("core-site.xml"));
	
		FileSystem fs = FileSystem.get(new URI(path),conf);
		FileStatus[] status = fs.listStatus(p1);
		for (int i=0;i<status.length;i++){
		String p=status[i].getPath().toString();
		long size=fs.getContentSummary(status[i].getPath()).getSpaceConsumed();
		String siz=idcstats.humanReadableByteCount(size,flag);
		
		System.out.println(p+"----"+siz);
		String sp[]=p.split("/");
		idc.put(sp[sp.length-1], siz);
		
		}
	
    long total_size=fs.getContentSummary(p1).getSpaceConsumed();
    
    String total_size_units=idcstats.humanReadableByteCount(total_size,flag);
    System.out.println(p1+"----"+total_size_units);
    String sp[]=path.split("/");
    idc.put(sp[sp.length-1], total_size_units);

	return idc;
	}
	
	
	
	
	/*public static void main (String args[]) throws IOException, URISyntaxException
	{
	idcstats obj=new idcstats();
	obj.getIDCStats(args[0],new Boolean(args[1]));
	}*/
	
	
	
	
	public static String humanReadableByteCount(long bytes, boolean si) {
	   /* int unit = si ? 1000 : 1024;
	    if (bytes < unit) return bytes + " B";
	    int exp = (int) (Math.log(bytes) / Math.log(unit));
	    String pre = (si ? "kMGTPE" : "KMGTPE").charAt(exp-1) + (si ? "" : "");
	    return String.format("%.1f %sB", bytes / Math.pow(unit, exp), pre);*/
		
		double mb=(double)bytes/(1024*1024*1024);
		String s=new Double(mb).toString() +" "+"GB";
		return s;
	}
}