package org.symantec.metrics.dashboard;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class CollectConfiguration extends DefaultHandler {

    
	 static Map<String,String> confs=new HashMap<String,String>();
	 static ArrayList<String> names=new ArrayList<String>();
	 static ArrayList<String> values=new ArrayList<String>();
	 boolean name=false;
	 boolean value=false;
	//CollectConfiguration(String filename) throws ParserConfigurationException,
		//	SAXException, IOException {

	
	public static Map<String,String> getConf(String filename) throws SAXException, IOException, ParserConfigurationException
	{
		CollectConfiguration handler = new CollectConfiguration();

		SAXParserFactory factory = SAXParserFactory.newInstance();

		factory.setValidating(false);

		SAXParser parser = factory.newSAXParser();
      
		parser.parse(new File(filename), handler);
		
		for(int i=0;i<names.size();i++)
		{
			confs.put(names.get(i), values.get(i));
		
		}
		return confs;

		
	}
	
	@Override
	public void startElement(String uri, String localName, String qName,
			Attributes attributes) throws SAXException {
     if(qName.equals("name"))
     {
    	name=true;
     }
     
	
     if(qName.equals("value"))
     {
    	value=true;
     }
    

	
	}
	
	 @Override
	   public void characters(char ch[], 
	      int start, int length) throws SAXException {
	if(name)
	{
		
		 names.add(new String(ch,start,length));
	name=false;
	}
	if(value)
	{
		
		 values.add(new String(ch,start,length));
	value=false;
	}
	 }
	 }

	
	

