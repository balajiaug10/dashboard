package org.symantec.metrics.dashboard;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class services {
String service_name;
String state;
Map<String, Long> service_metrics = new HashMap<String, Long>();
ArrayList<String> service_metrics_name = new ArrayList<String>();
public void setService(String ser,String state,Map<String,Long> metrics)
{
	service_name=ser;
	this.state=state;
	service_metrics=metrics;
	service_metrics_name = new ArrayList<String>(service_metrics.keySet());
}

}
