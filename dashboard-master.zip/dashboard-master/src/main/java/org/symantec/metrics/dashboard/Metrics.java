package org.symantec.metrics.dashboard;

class Metrics
{
	String metricKey;
	String metricValue;
	public String getMetrics(String mk)
	{
		return metricValue;
	}
	
	public void setMetrics(String mk,String val)
	{
		metricKey=mk;
		metricValue=val;
	}
}