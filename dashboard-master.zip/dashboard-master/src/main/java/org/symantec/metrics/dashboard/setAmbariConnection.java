package org.symantec.metrics.dashboard;

import javax.net.ssl.SSLContext;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.client.config.ClientConfig;
import com.sun.jersey.api.client.config.DefaultClientConfig;
import com.sun.jersey.api.client.filter.HTTPBasicAuthFilter;
import com.sun.jersey.api.json.JSONConfiguration;

public class setAmbariConnection {
	
static String uid,password;	
public static void setCred(String username,String pass)
{
	uid=username;
	password=pass;
}


public StringBuilder getConnection(String href)
{
	
	//System.out.println(href+"pojo");
	ClientConfig clientConfig = new DefaultClientConfig();
    clientConfig.getFeatures().put(JSONConfiguration.FEATURE_POJO_MAPPING,
            Boolean.TRUE);       
    Client client = Client.create(clientConfig);
    client.addFilter(new HTTPBasicAuthFilter(uid,
            password));
   SSLTool.disableCertificateValidation();
    WebResource webResource = client
            .resource(href);  
    
    StringBuilder content = new StringBuilder();
    try {
    	
        String s = webResource.get(String.class);
        
        if (s != null) {
        	//System.out.println(s);
        	content.append(s + "\n");
        
        }        } catch (Exception ex) {
        	System.out.println("exp");
        	ex.printStackTrace();
        System.err.println(ex.getMessage());
    } 
  return content;
}
}
