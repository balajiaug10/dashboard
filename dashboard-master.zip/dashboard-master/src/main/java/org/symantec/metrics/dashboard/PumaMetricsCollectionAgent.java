package org.symantec.metrics.dashboard;


import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Map;


import javax.xml.parsers.ParserConfigurationException;

import org.xml.sax.SAXException;

public class PumaMetricsCollectionAgent {
	private static String driverName = "org.apache.hive.jdbc.HiveDriver";
	private static Connection connection;
	private static Connection con;
	
	private static String sqlhost, port,database, sqluid, sqlpass,hive2host,hive2port,queuename,hive2uid,hive2pass;
	private static int CLUSTER_ID;

	public void startPuma(Map<String,String> conf,int clusterid) throws SAXException, IOException, ParserConfigurationException, SQLException
	{
		
		sqlhost = conf.get("dashboard.sql.hostname");
		port = conf.get("dashboard.sql.port");
		database = conf.get("dashboard.sql.database");
		sqluid = conf.get("dashboard.sql.username");
		sqlpass = conf.get("dashboard.sql.password");
		hive2host=conf.get("dashboard.hive2.hostname");
		hive2port = conf.get("dashboard.hive2.port");
		hive2uid = conf.get("dashboard.hive2.username");
		hive2pass = conf.get("dashboard.hive2.password");
		queuename = conf.get("dashboard.puma.job.queue.name");
		CLUSTER_ID=clusterid;
		this.setConnection();
		this.initPuma();
		this.setJobMetrics();
		this.setSystemMetrics();
		this.setPerfAndWorkloadMetrics();
	    this.cleanConnection();
	}
	

	public Connection setConnection() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			String sqlurl = "jdbc:mysql://"+sqlhost+":"+port+"/"+database;
			
			connection = DriverManager.getConnection(sqlurl, sqluid,
					sqlpass);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return connection;
	}

	public void initPuma() throws SQLException {

		
		try {
			Class.forName(driverName);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.exit(1);
		}

		con = DriverManager
				.getConnection(
						"jdbc:hive2://"+hive2host+":"+hive2port+"?mapred.job.queue.name="+queuename,
						hive2uid, hive2pass);

	System.out.println("jdbc:hive2://"+hive2host+":"+hive2port+"?mapred.job.queue.name="+queuename);

		Statement stmt = con.createStatement();
		ArrayList<String> conf = new ArrayList<String>();
		conf.add("set hivevar:HIVE_DB_NAME=PUMA");
		conf.add(" set CPU_COST_PER_HOUR=0.004");
		conf.add("set MEMORY_COST_PER_GB_PER_HOUR=0.004");
		conf.add("set DATA_IO_COST_PER_GB=0.02");
		conf.add("set NETWORK_IO_COST_PER_GB=0.02");
		conf.add(" set DATA_COST_PER_IOP=0.0002");

		ArrayList<String> init = new ArrayList<String>();
		init.add("add jar hdfs://CP1-PROD-ASH2/user/balaji_ganesula/puma-hive-udf-hive-0.13-1.0-jar-with-dependencies.jar");
		init.add("add jar hdfs://CP1-PROD-ASH2/user/balaji_ganesula/puma-json-serde-1.1.9.6-20141017.041056-1-jar-with-dependencies.jar");
		init.add("set hive.cli.errors.ignore=true");
		init.add("set hive.cli.print.header=true");
		init.add("set hive.exec.dynamic.partition.mode = nonstrict");
		init.add("set hive.exec.dynamic.partitions= true");
		init.add("set hive.exec.max.dynamic.partitions.pernode=10000");
		init.add("set hive.exec.max.dynamic.partitions=10000");
		init.add("set hive.exec.parallel.thread.number=10");
		init.add("set hive.exec.parallel=true");
		init.add("set hive.exec.reducers.max=9999");
		init.add("set hive.support.concurrency=false");
		init.add("set hive.hadoop.supports.splittable.combineinputformat=true");
		init.add("set hive.merge.mapfiles=false");
		init.add("set mapred.child.opts=-Xmx1024m");
		init.add("set mapreduce.input.fileinputformat.split.maxsize=256000000");
		init.add("set mapreduce.input.fileinputformat.split.minsize.per.node=128000000");
		init.add("set mapreduce.input.fileinputformat.split.minsize.per.rack=128000000");
		init.add("set mapreduce.input.fileinputformat.split.minsize=128000000");
		init.add("set mapreduce.job.counters.max=1000");
		init.add("set mapreduce.job.queuename=default");
		init.add("set mapreduce.job.reduce.slowstart.completedmaps=0.7");
		init.add("set mapreduce.map.opts=-Xmx2024m");
		init.add("set mapreduce.map.memory.mb=2024");
		init.add("set mapreduce.reduce.opts=-Xmx2024m");
		init.add("set mapreduce.reduce.memory.mb=2024");
		init.add("set mapreduce.task.io.sort.mb=256");
		init.add("set hive.exec.compress.output=false");
		init.add("set mapred.output.compress=false");
		init.add("set mapred.compress.map.output=true");
		init.add("set mapred.output.compression.codec=org.apache.hadoop.io.compress.SnappyCodec");
		init.add("set mapred.output.compression.type=BLOCK");
		init.add("set hive.vectorized.execution.enabled=false");
		init.add("set hive.input.format=org.apache.hadoop.hive.ql.io.HiveInputFormat");
		init.add("set hive.txn.manager=org.apache.hadoop.hive.ql.lockmgr.DbTxnManager");
		init.add("set hive.support.concurrency=true");
		init.add("set hive.execution.engine=tez");
		
		init.add("use puma");

		for (int i = 0; i < conf.size(); i++) {
			stmt.execute(conf.get(i));
		
		}
		for (int i = 0; i < init.size(); i++) {
			stmt.execute(init.get(i));
		}
	}

	public void setJobMetrics() throws SQLException {
	
		Calendar calendar = Calendar.getInstance();
		java.sql.Timestamp ourJavaTimestampObject = new java.sql.Timestamp(
				calendar.getTime().getTime());
		Statement stmt = con.createStatement();
		Statement stmt1 = connection.createStatement();
		String sql1;
		ResultSet res;

		System.out.println("Setting job metrics");
		
		res = stmt
				.executeQuery("select user_name,status,num_of_jobs from job_status_by_user_yesterday");

		sql1 = "delete from job_status_by_user_yesterday where cluster_id="+CLUSTER_ID;
		stmt1.executeUpdate(sql1);
		while (res.next()) {

			String sql = "insert into job_status_by_user_yesterday values ("+CLUSTER_ID+",'"
					+ res.getString("user_name")
					+ "','"
					+ res.getString("status")
					+ "',"
					+ res.getInt("num_of_jobs")
					+ ",'"
					+ ourJavaTimestampObject
					+ "')";
		
			stmt1.executeUpdate(sql);
		}


		System.out.println("Setting long waiting job metrics");

		res = stmt
				.executeQuery("select user_name,queue_name,job_id,job_name,job_submission_wait_millis,job_submission_wait,job_finish_date,rank from long_waiting_job_by_user_yesterday_top_10");
		
		sql1 = "delete from long_waiting_job_by_user_yesterday_top_10 where cluster_id="+CLUSTER_ID;
		stmt1.executeUpdate(sql1);
		while (res.next()) {

			String sql = "insert into long_waiting_job_by_user_yesterday_top_10 values ("+CLUSTER_ID+",'"
					+ res.getString("user_name")
					+ "','"
					+ res.getString("queue_name")
					+ "','"
					+ res.getString("job_id")
					+ "','"
					+ res.getString("job_name")
					+ "',"
					+ res.getLong("job_submission_wait_millis")
					+ ",'"
					+ res.getString("job_submission_wait")
					+ "','"
					+ res.getString("job_finish_date")
					+ "',"
					+ res.getInt("rank") + ",'" + ourJavaTimestampObject + "')";
			
			stmt1.executeUpdate(sql);
		}

		System.out.println("Setting resource wasting job metrics");
	

		res = stmt
				.executeQuery("select job_id,job_name,user_name,queue_name,unused_memory_total_gb,wasted_memory_per_map_gb,"
						+ "wasted_memory_per_reduce_gb,"
						+ "total_maps,total_reduces,requested_map_gb,requested_reduce_gb,avg_requested_task_gb,"
						+ "avg_memory_used_per_map_gb,avg_memory_used_per_reduce_gb,avg_memory_used_per_task_gb,"
						+ "memory_blocked_for_job_total_gb,commited_heap_gb,recommended_memory_map_gb,recommended_memory_reduce_gb,"
						+ "job_finish_date,rank from resource_wasting_job_by_user_yesterday_top_10");
		sql1 = "delete from resource_wasting_job_by_user_yesterday_top_10 where cluster_id="+CLUSTER_ID;
		stmt1.executeUpdate(sql1);
	
		while (res.next()) {

			String sql = "insert into resource_wasting_job_by_user_yesterday_top_10 values ("+CLUSTER_ID+",'"
					+ res.getString("user_name")
					+ "','"
					+ res.getString("queue_name")
					+ "','"
					+ res.getString("job_id")
					+ "','"
					+ res.getString("job_name").replaceAll("'", "")
					+ "',"
					+ res.getDouble("unused_memory_total_gb")
					+ ","
					+ res.getDouble("wasted_memory_per_map_gb")
					+ ","
					+ res.getDouble("wasted_memory_per_reduce_gb")
					+ ","
					+ res.getInt("total_maps")
					+ ","
					+ res.getInt("total_reduces")
					+ ","
					+ res.getDouble("requested_map_gb")
					+ ","
					+ res.getDouble("requested_reduce_gb")
					+ ","
					+ res.getDouble("avg_requested_task_gb")
					+ ","
					+ res.getDouble("avg_memory_used_per_map_gb")
					+ ","
					+ res.getDouble("avg_memory_used_per_reduce_gb")
					+ ","
					+ res.getDouble("avg_memory_used_per_task_gb")
					+ ","
					+ res.getDouble("memory_blocked_for_job_total_gb")
					+ ","
					+ res.getDouble("commited_heap_gb")
					+ ","
					+ res.getDouble("recommended_memory_map_gb")
					+ ","
					+ res.getDouble("recommended_memory_reduce_gb")
					+ ",'"
					+ res.getString("job_finish_date")
					+ "',"
					+ res.getInt("rank") + ",'" + ourJavaTimestampObject + "')";

			stmt1.executeUpdate(sql);
		}

	}

	public void setSystemMetrics() throws SQLException {
	
		Calendar calendar = Calendar.getInstance();
		java.sql.Timestamp ourJavaTimestampObject = new java.sql.Timestamp(
				calendar.getTime().getTime());
		Statement stmt = con.createStatement();
		Statement stmt1 = connection.createStatement();
		String sql1;
		ResultSet res;

	

		res = stmt
				.executeQuery("select user_name,total_cpu_used_hours,total_cpu_used_display from cpu_usage_by_user_yesterday_top_10");
		sql1 = "delete from cpu_usage_by_user_yesterday_top_10 where cluster_id="+CLUSTER_ID;
		stmt1.executeUpdate(sql1);
		while (res.next()) {

			String sql = "insert into cpu_usage_by_user_yesterday_top_10 values ("+CLUSTER_ID+",'"
					+ res.getString("user_name")
					+ "',"
					+ res.getDouble("total_cpu_used_hours")
					+ ",'"
					+ res.getString("total_cpu_used_display")
					+ "','"
					+ ourJavaTimestampObject + "')";

		
			stmt1.executeUpdate(sql);
		}

	

		res = stmt
				.executeQuery("select user_name,total_data_processed_including_replication_gb,total_data_processed_gb,file_data_read_gb,"
						+ "file_data_written_gb,file_total_data_processed_gb,hdfs_data_read_gb,"
						+ "hdfs_data_written_gb,hdfs_data_written_including_replication_gb,total_hdfs_data_processed_gb,"
						+ "total_hdfs_data_processed_including_replication_gb,total_data_read_gb,total_data_written_gb,"
						+ "total_data_written_including_replication,file_read_ops,file_large_read_ops,file_write_ops,"
						+ "total_file_read_write_ops,hdfs_read_ops,hdfs_large_read_ops,hdfs_write_ops,total_hdfs_read_write_ops,"
						+ "total_read_ops,total_write_ops,total_read_write_ops from diskio_usage_by_user_yesterday_top_10");

		sql1 = "delete from diskio_usage_by_user_yesterday_top_10 where cluster_id="+CLUSTER_ID;
		stmt1.executeUpdate(sql1);
		while (res.next()) {

			String sql = "insert into diskio_usage_by_user_yesterday_top_10 values ("+CLUSTER_ID+",'"
					+ res.getString("user_name")
					+ "',"
					+ res.getDouble("total_data_processed_including_replication_gb")
					+ ","
					+ res.getDouble("total_data_processed_gb")
					+ ","
					+ res.getDouble("file_data_read_gb")
					+ ","
					+ res.getDouble("file_data_written_gb")
					+ ","
					+ res.getDouble("file_total_data_processed_gb")
					+ ","
					+ res.getDouble("hdfs_data_read_gb")
					+ ","
					+ res.getDouble("hdfs_data_written_gb")
					+ ","
					+ res.getDouble("hdfs_data_written_including_replication_gb")
					+ ","
					+ res.getDouble("total_hdfs_data_processed_gb")
					+ ","
					+ res.getDouble("total_hdfs_data_processed_including_replication_gb")
					+ ","
					+ res.getDouble("total_data_read_gb")
					+ ","
					+ res.getDouble("total_data_written_gb")
					+ ","
					+ res.getDouble("total_data_written_including_replication")
					+ ","
					+ res.getInt("file_read_ops")
					+ ","
					+ res.getInt("file_large_read_ops")
					+ ","
					+ res.getInt("file_write_ops")
					+ ","
					+ res.getInt("total_file_read_write_ops")
					+ ","
					+ res.getInt("hdfs_read_ops")
					+ ","
					+ res.getInt("hdfs_large_read_ops")
					+ ","
					+ res.getInt("hdfs_write_ops")
					+ ","
					+ res.getInt("total_hdfs_read_write_ops")
					+ ","
					+ res.getInt("total_read_ops")
					+ ","
					+ res.getInt("total_write_ops")
					+ ","
					+ res.getInt("total_read_write_ops")
					+ ",'"
					+ ourJavaTimestampObject + "')";

			stmt1.executeUpdate(sql);
		}




		res = stmt
				.executeQuery("select user_name,total_used_memory_gb,total_used_memory_display from memory_usage_by_user_yesterday_top_10");


		sql1 = "delete from memory_usage_by_user_yesterday_top_10 where cluster_id="+CLUSTER_ID;
		stmt1.executeUpdate(sql1);
		while (res.next()) {

			String sql = "insert into memory_usage_by_user_yesterday_top_10 values ("+CLUSTER_ID+",'"
					+ res.getString("user_name")
					+ "',"
					+ res.getDouble("total_used_memory_gb")
					+ ",'"
					+ res.getString("total_used_memory_display")
					+ "','"
					+ ourJavaTimestampObject + "')";

			
			stmt1.executeUpdate(sql);
		}

	}

	public void setPerfAndWorkloadMetrics() throws SQLException {
	
		Calendar calendar = Calendar.getInstance();
		java.sql.Timestamp ourJavaTimestampObject = new java.sql.Timestamp(
				calendar.getTime().getTime());
		Statement stmt = con.createStatement();
		Statement stmt1 = connection.createStatement();
		String sql1;
		ResultSet res;


		

		res = stmt
				.executeQuery("select user_name,job_submit_hour,number_of_jobs,number_of_tasks,total_data_processed,total_data_processed_display,"
						+ "total_memory_used,total_memory_used_display,total_cpu_time_used,"
						+ "total_cpu_time_used_display from hourly_workload_distribution_by_user_yesterday");
		sql1 = "delete from  hourly_workload_distribution_by_user_yesterday where cluster_id="+CLUSTER_ID;
		stmt1.executeUpdate(sql1);
		while (res.next()) {
			String sql = "insert into hourly_workload_distribution_by_user_yesterday values ("+CLUSTER_ID+",'"
					+ res.getString("user_name")
					+ "',"
					+ res.getInt("job_submit_hour")
					+ ","
					+ res.getInt("number_of_jobs")
					+ ","
					+ res.getInt("number_of_tasks")
					+ ","
					+ res.getDouble("total_data_processed")
					+ ",'"
					+ res.getString("total_data_processed_display")
					+ "',"
					+ res.getDouble("total_memory_used")
					+ ",'"
					+ res.getString("total_memory_used_display")
					+ "',"
					+ res.getDouble("total_cpu_time_used")
					+ ",'"
					+ res.getString("total_cpu_time_used_display")
					+ "','"
					+ ourJavaTimestampObject + "')";

			
			stmt1.executeUpdate(sql);
		}
		
		

		res = stmt
				.executeQuery("select rule_title,count(1) as cou from perf_analysis p,mr_job_history "
						+ "mr where p.job_id=mr.job_id group by rule_title order by 1 desc limit 5");
		sql1 = "delete from  perf_analaysis  where cluster_id=1003";
		stmt1.executeUpdate(sql1);
		while (res.next()) {
			String sql = "insert into perf_analaysis values ("+CLUSTER_ID+",'"
					+ res.getString("rule_title") + "'," + res.getInt("cou")
					+ ",'" + ourJavaTimestampObject + "')";
		
			stmt1.executeUpdate(sql);
		}

	}

	public void cleanConnection() throws SQLException {
		con.close();
		connection.close();
	}



	

		

	
}
