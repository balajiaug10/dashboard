package org.symantec.metrics.dashboard;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URISyntaxException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import javax.xml.parsers.ParserConfigurationException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.influxdb.InfluxDB;
import org.influxdb.InfluxDB.ConsistencyLevel;
import org.influxdb.InfluxDBFactory;
import org.influxdb.dto.BatchPoints;
import org.influxdb.dto.Point;
import org.influxdb.impl.*;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.xml.sax.SAXException;

import retrofit.ErrorHandler;

public class CollectionAgent implements Runnable {

	private Thread t;
	private static String serverName, proxy, ambariVersion, sqlhost, port,
			database, sqluid, sqlpass, datacenter;
	private static boolean pumaenable;
	private static long arpfreq, servicefreq, pumafreq;
	private String threadName;
	private String ava_url, ava_url1, rel_url, rel_url1, perf_url;
	private static String ser_url;
	private static String uid;
	private static String password;
	private String ini_url;
	private Connection connection;
	private Statement stmt = null;
	private String Status = "Started";
	private static String CLUSTER_NAME, DATA_CENTER, VERSION, HREF;
	private static int Cluster_Id = 1000;
	private int Metrics_Id = 100;
	private Map<String, String> servicemetadata = new HashMap<String, String>();
	private static Map<String, String> conf;
	private static String idcpath;
	private static String units;
	private static String webhdfsuri;
	private static String influxDB_URL;
	private static String influxDB_uid;
	private static String influxDB_pass;
	private static String influxDB_database;
	private static String idc_partition_name;
	private static boolean idcenable;
	ArrayList<String> com;
	Map<String, Long> Ava_metrics = new HashMap<String, Long>();

	ArrayList<services> ava_ser_metrics = new ArrayList<services>();

	Map<String, Long> Rel_metrics = new HashMap<String, Long>();

	ArrayList<services> rel_ser_metrics = new ArrayList<services>();

	Map<String, Long> Perf_metrics = new HashMap<String, Long>();

	ArrayList<services> perf_ser_metrics = new ArrayList<services>();
	private static long idcfreq;
	private static String avametcomponents;
	private static String email_id;

	// Thread
	CollectionAgent(String name) {
		threadName = name;
	}

	// To Establish DataBase Connection
	public Connection setConnection() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			String sqlurl = "jdbc:mysql://" + sqlhost + ":" + port + "/"
					+ database;

			connection = DriverManager.getConnection(sqlurl, sqluid, sqlpass);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return connection;
	}

	// Cluster Initialization
	public void initCluster() throws SQLException, IOException, ParseException {

		ini_url = CollectionAgent.serverName + "/api/v1/clusters";
		// System.out.println(ini_url);
		StringBuilder content = new setAmbariConnection()
				.getConnection(this.ini_url);

		JSONParser parser = new JSONParser();
		Object obj = parser.parse(content.toString());
		JSONObject jsonObject = (JSONObject) obj;
		JSONArray items = (JSONArray) jsonObject.get("items");
		JSONObject item_list = (JSONObject) items.get(0);
		JSONObject clusters = (JSONObject) item_list.get("Clusters");
		CLUSTER_NAME = (String) clusters.get("cluster_name");
		DATA_CENTER = CollectionAgent.datacenter;
		VERSION = (String) clusters.get("version");
		HREF = (String) item_list.get("href");

		if (proxy.equals("true")) {
			HREF = HREF.replace("http", "https");
		}

		ava_url = HREF + "/" + "services";
		ava_url1 = HREF;

		rel_url = HREF + "/" + "components/NAMENODE";
		rel_url1 = HREF + "/" + "components/RESOURCEMANAGER";

		perf_url = HREF + "/" + "components/RESOURCEMANAGER";
		ser_url = HREF + "/" + "hosts";
		int flag = 1;
		Statement stmt = connection.createStatement();
		String sql = "select * from Cluster";
		ResultSet rs = stmt.executeQuery(sql);

		while (rs.next()) {
			Cluster_Id = Math.max(Cluster_Id, rs.getInt("cluster_id"));
			if (rs.getString("cluster_name").equals(CLUSTER_NAME)) {
				flag = 0;
				break;
			} else {
				flag = 1;
			}
		}

		if (flag == 1) {
			Cluster_Id = Cluster_Id + 1;
			sql = "INSERT INTO Cluster VALUES (" + Cluster_Id + ",'"
					+ CLUSTER_NAME + "','" + DATA_CENTER + "','" + Status
					+ "','" + VERSION + "')";
			stmt.executeUpdate(sql);
		}
	}

	// Availability Metrics collection
	public void getAvailableMetricProperties() throws IOException,
			ParseException {

		StringBuilder content = new setAmbariConnection()
				.getConnection(this.ava_url);

		JSONParser parser = new JSONParser();
		Object obj = parser.parse(content.toString());
		JSONObject jsonObject = (JSONObject) obj;
		JSONArray items = (JSONArray) jsonObject.get("items");
		for (int i = 0; i < items.size(); i++) {
			Map<String, Long> Ava_ser_metrics = new HashMap<String, Long>();
			JSONObject jsonitems = (JSONObject) items.get(i);
			String href = (String) jsonitems.get("href");
			if (proxy.equals("true")) {
				href = href.replace("http", "https");
			}

			StringBuilder content1 = new setAmbariConnection()
					.getConnection(href);
			JSONParser parser1 = new JSONParser();
			Object obj1 = parser1.parse(content1.toString());
			JSONObject jsonObject1 = (JSONObject) obj1;
			JSONObject ServiceInfo = (JSONObject) jsonObject1
					.get("ServiceInfo");

			JSONObject alerts_summary;

			if (CollectionAgent.ambariVersion.equals("1.6")) {
				JSONObject alerts = (JSONObject) jsonObject1.get("alerts");
				alerts_summary = (JSONObject) alerts.get("summary");
			} else {
				alerts_summary = (JSONObject) jsonObject1.get("alerts_summary");
			}

			String state = (String) ServiceInfo.get("state");
			String service_name = (String) ServiceInfo.get("service_name");
			long critical = (Long) alerts_summary.get("CRITICAL");
			long ok = (Long) alerts_summary.get("OK");
			long unknown;
			if (CollectionAgent.ambariVersion.equals("1.6")) {
				unknown = (Long) alerts_summary.get("PASSIVE");
			} else {
				unknown = (Long) alerts_summary.get("UNKNOWN");
			}

			long warning = (Long) alerts_summary.get("WARNING");
			Ava_ser_metrics.put("CRITICAL", new Long((long) critical));
			Ava_ser_metrics.put("OK", new Long((long) ok));
			Ava_ser_metrics.put("UNKNOWN", new Long((long) unknown));
			Ava_ser_metrics.put("WARNING", new Long((long) warning));

			services ser_obj = new services();
			ser_obj.setService(service_name, state, Ava_ser_metrics);
			ava_ser_metrics.add(ser_obj);

		}
		StringBuilder content1 = new setAmbariConnection()
				.getConnection(this.ava_url1);

		JSONParser parser1 = new JSONParser();
		Object obj1 = parser1.parse(content1.toString());
		JSONObject jsonObject1 = (JSONObject) obj1;
		JSONObject Clusters = (JSONObject) jsonObject1.get("Clusters");
		JSONObject health_report = (JSONObject) Clusters.get("health_report");

		long healthy = (Long) health_report.get("Host/host_state/HEALTHY");
		long stale = (Long) health_report.get("Host/stale_config");
		long unhealthy = (Long) health_report.get("Host/host_state/UNHEALTHY");
		long heartbeat_lost = (Long) health_report
				.get("Host/host_state/HEARTBEAT_LOST");

		Ava_metrics.put("HEALTHY", new Long((long) healthy));
		Ava_metrics.put("STALE", new Long((long) stale));
		Ava_metrics.put("UNHEALTHY", new Long((long) unhealthy));
		Ava_metrics.put("HEARTBEAT_LOST", new Long((long) heartbeat_lost));

		services ser_obj = new services();
		ser_obj.setService("CLUSTER", "Started", Ava_metrics);
		ava_ser_metrics.add(ser_obj);

	}

	// Cross cluster Availability Metrics

	public void getAvailableCrossMetricProperties() throws IOException,
			ParseException {

		// System.out.println(ava_url);
		this.com = new ArrayList<String>();
		String components[] = avametcomponents.split(",");

		for (int i = 0; i < components.length; i++) {
			String com_url = ava_url + "/" + components[i].toUpperCase();
			// System.out.println(com_url);
			StringBuilder content1 = new setAmbariConnection()
					.getConnection(com_url);
			JSONParser parser1 = new JSONParser();
			Object obj1 = parser1.parse(content1.toString());
			JSONObject jsonObject1 = (JSONObject) obj1;
			JSONArray Components = (JSONArray) jsonObject1.get("components");
			for (int j = 0; j < Components.size(); j++) {

				JSONObject jsonitems = (JSONObject) Components.get(j);
				String href = (String) jsonitems.get("href");
				if (proxy.equals("true")) {
					href = href.replace("http", "https");
				}
				StringBuilder content2 = new setAmbariConnection()
						.getConnection(href);
				JSONParser parser2 = new JSONParser();
				Object obj2 = parser2.parse(content2.toString());
				JSONObject jsonObject2 = (JSONObject) obj2;
				JSONObject ServiceComponentInfo = (JSONObject) jsonObject2
						.get("ServiceComponentInfo");
				long started_count = (Long) ServiceComponentInfo
						.get("started_count");
				long total_count = (Long) ServiceComponentInfo
						.get("total_count");
				// System.out.println(components[i].toUpperCase() + ","
				// + href.split("/")[href.split("/").length - 1] + ","
				// + started_count + "," + total_count);
				String component_met = components[i].toUpperCase() + ","
						+ href.split("/")[href.split("/").length - 1] + ","
						+ started_count + "," + total_count;
				this.com.add(component_met);

			}
		}
	}

	public void setAvaCrossMetrics() throws SQLException {

		Calendar calendar = Calendar.getInstance();
		java.sql.Timestamp ourJavaTimestampObject = new java.sql.Timestamp(
				calendar.getTime().getTime());

		stmt = connection.createStatement();
		String sql;
		for (int i = 0; i < this.com.size(); i++) {
			String metrics[] = this.com.get(i).split(",");

			int flag = 0;
			String sql1 = "select * from Availability_Cross_Metrics where cluster_id=(select cluster_id from Cluster where cluster_name='"
					+ CLUSTER_NAME
					+ "') and metrics_group='"
					+ metrics[0]
					+ "' and component='" + metrics[1] + "'";
			System.out.println(sql1);
			ResultSet rs = stmt.executeQuery(sql1);
			while (rs.next()) {
				flag++;
			}

			if (flag == 0) {

				sql = "INSERT INTO Availability_Cross_Metrics VALUES ("
						+ Cluster_Id + ",'" + metrics[0] + "','" + metrics[1]
						+ "'," + metrics[2] + "," + metrics[3] + ",'"
						+ ourJavaTimestampObject + "')";
				System.out.println(sql);
				stmt.executeUpdate(sql);
			}

			else {
				sql = "Update Availability_Cross_Metrics set started_count="
						+ metrics[2]
						+ ","
						+ "total_count="
						+ metrics[3]
						+ ","
						+ "datetimestamp='"
						+ ourJavaTimestampObject
						+ "' where cluster_id=(select cluster_id from Cluster where cluster_name='"
						+ CLUSTER_NAME + "') and metrics_group='" + metrics[0]
						+ "' and component='" + metrics[1] + "'";
				// System.out.println(sql);
				stmt.executeUpdate(sql);

			}

		}
	}

	// Availability Metrics Upload
	public void setAvaMetrics() throws SQLException {

		Calendar calendar = Calendar.getInstance();
		java.sql.Timestamp ourJavaTimestampObject = new java.sql.Timestamp(
				calendar.getTime().getTime());

		stmt = connection.createStatement();
		String sql;

		for (int i = 0; i < ava_ser_metrics.size(); i++) {

			int flag = 0;
			String sql1 = "select * from Availability_Metrics where cluster_id=(select cluster_id from Cluster where cluster_name='"
					+ CLUSTER_NAME
					+ "') and metrics_group='"
					+ ava_ser_metrics.get(i).service_name + "'";
			ResultSet rs = stmt.executeQuery(sql1);
			while (rs.next()) {
				flag++;
			}

			if (flag == 0) {

				String sql2 = "select max(metrics_id) as count from Availability_Metrics";
				ResultSet rs2 = stmt.executeQuery(sql2);
				while (rs2.next()) {
					Metrics_Id = rs2.getInt("count") + 1;
				}

				for (int j = 0; j < ava_ser_metrics.get(i).service_metrics
						.size(); j++) {

					sql = "INSERT INTO Availability_Metrics VALUES ("
							+ Cluster_Id
							+ ","
							+ Metrics_Id
							+ ",'"
							+ ava_ser_metrics.get(i).service_metrics_name
									.get(j)
							+ "',"
							+ ava_ser_metrics.get(i).service_metrics
									.get(ava_ser_metrics.get(i).service_metrics_name
											.get(j)) + ",'"
							+ ourJavaTimestampObject + "'," + "'"
							+ ava_ser_metrics.get(i).service_name + "'" + ")";

					stmt.executeUpdate(sql);

					sql = "INSERT INTO service_status VALUES (" + Cluster_Id
							+ ",'" + ava_ser_metrics.get(i).service_name
							+ "','" + ava_ser_metrics.get(i).state + "','"
							+ ourJavaTimestampObject + "')";

					stmt.executeUpdate(sql);
					Metrics_Id = Metrics_Id + 1;
				}
			}

			else {

				for (int j = 0; j < ava_ser_metrics.get(i).service_metrics
						.size(); j++) {
					sql = "Update Availability_Metrics set metrics_value="
							+ ava_ser_metrics.get(i).service_metrics
									.get(ava_ser_metrics.get(i).service_metrics_name
											.get(j))
							+ ","
							+ "datetimestamp='"
							+ ourJavaTimestampObject
							+ "' where cluster_id=(select cluster_id from Cluster where cluster_name='"
							+ CLUSTER_NAME
							+ "') and metrics_name='"
							+ ava_ser_metrics.get(i).service_metrics_name
									.get(j) + "' and metrics_group='"
							+ ava_ser_metrics.get(i).service_name + "'";
					stmt.executeUpdate(sql);

					sql = "Update service_status set status="
							+ "'"
							+ ava_ser_metrics.get(i).state
							+ "', datetimestamp='"
							+ ourJavaTimestampObject
							+ "' where cluster_id=(select cluster_id from Cluster where cluster_name='"
							+ CLUSTER_NAME + "') and service_name='"
							+ ava_ser_metrics.get(i).service_name + "'";
					// System.out.println(sql);
					stmt.executeUpdate(sql);

				}
			}

		}

	}

	// Reliability Metrics Collection
	public void getReliabitityMetricProperties() throws IOException,
			ParseException {
		// System.out.println(this.rel_url+"888");
		StringBuilder content_con = new setAmbariConnection()
				.getConnection(this.rel_url);

		JSONParser parser_con = new JSONParser();
		Object obj_con = parser_con.parse(content_con.toString());
		JSONObject jsonObject_con = (JSONObject) obj_con;
		JSONArray host_components = (JSONArray) jsonObject_con
				.get("host_components");
		JSONObject component = (JSONObject) host_components.get(0);
		String url = (String) component.get("href");
		if (proxy.equals("true")) {
			url = url.replace("http", "https");
		}

		StringBuilder content = new setAmbariConnection().getConnection(url);
		JSONParser parser = new JSONParser();
		Object obj = parser.parse(content.toString());
		JSONObject jsonObject = (JSONObject) obj;

		JSONObject metrics = (JSONObject) jsonObject.get("metrics");
		JSONObject dfs = (JSONObject) metrics.get("dfs");
		JSONObject FSNamesystem = (JSONObject) dfs.get("FSNamesystem");

		long blockcapacity = (Long) FSNamesystem.get("BlockCapacity");
		long blocktotal = (Long) FSNamesystem.get("BlocksTotal");
		long capacityremaining = (Long) FSNamesystem.get("CapacityRemaining");
		double capacityremainingGB = (Double) FSNamesystem
				.get("CapacityRemainingGB");
		long capacitytotal = (Long) FSNamesystem.get("CapacityTotal");
		double capacitytotalGB = (Double) FSNamesystem.get("CapacityTotalGB");
		long capacityused = (Long) FSNamesystem.get("CapacityUsed");
		double capacityusedGB = (Double) FSNamesystem.get("CapacityUsedGB");
		long corruptblocks = (Long) FSNamesystem.get("CorruptBlocks");
		long excessblocks = (Long) FSNamesystem.get("ExcessBlocks");
		long filestotal = (Long) FSNamesystem.get("FilesTotal");
		long missingblocks = (Long) FSNamesystem.get("MissingBlocks");
		long pendingdeletionblocks = (Long) FSNamesystem
				.get("PendingDeletionBlocks");
		long pendingreplicationblocks = (Long) FSNamesystem
				.get("PendingReplicationBlocks");
		long scheduledreplicationblocks = (Long) FSNamesystem
				.get("ScheduledReplicationBlocks");
		long totalload = (Long) FSNamesystem.get("TotalLoad");
		long underreplicatedblocks = (Long) FSNamesystem
				.get("UnderReplicatedBlocks");

		Rel_metrics.put("BLOCK_CAPACITY", new Long((long) blockcapacity));
		Rel_metrics.put("BLOCK_TOTAL", new Long((long) blocktotal));
		Rel_metrics.put("CAPACITY_REMAINING",
				new Long((long) capacityremaining));
		Rel_metrics.put("CAPACITY_REMAINING_TB", new Long(
				(long) capacityremainingGB / 1024));
		Rel_metrics.put("CAPACITY_TOTAL", new Long((long) capacitytotal));
		Rel_metrics.put("CAPACITY_TOTAL_TB", new Long(
				(long) capacitytotalGB / 1024));
		Rel_metrics.put("CAPACITY_USED", new Long((long) capacityused));
		Rel_metrics.put("CAPACITY_USED_TB", new Long(
				(long) capacityusedGB / 1024));
		Rel_metrics.put("CURRUPT_BLOCKS", new Long((long) corruptblocks));
		Rel_metrics.put("EXCESS_BLOCKS", new Long((long) excessblocks));
		Rel_metrics.put("FILES_TOTAL", new Long((long) filestotal));
		Rel_metrics.put("MISSING_BLOCKS", new Long((long) missingblocks));
		Rel_metrics.put("PENDING_DELETION_BLOCKS", new Long(
				(long) pendingdeletionblocks));
		Rel_metrics.put("PENDING_REPLICATION_BLOCKS", new Long(
				(long) pendingreplicationblocks));
		Rel_metrics.put("SCHEDULED_REPLICATION_BLOCKS", new Long(
				(long) scheduledreplicationblocks));
		Rel_metrics.put("TOTAL_LOAD", new Long((long) totalload));
		Rel_metrics.put("UNDERREPLICATED_BLOCKS", new Long(
				(long) underreplicatedblocks));

		services ser_obj = new services();
		ser_obj.setService("HDFS", "Started", Rel_metrics);
		rel_ser_metrics.add(ser_obj);

		// Yarn Metrics
		Map<String, Long> Rel_ser_metrics = new HashMap<String, Long>();

		StringBuilder content1_con1 = new setAmbariConnection()
				.getConnection(this.rel_url1);
		// System.out.println(this.rel_url1);
		JSONParser parser_con1 = new JSONParser();
		Object obj_con1 = parser_con1.parse(content1_con1.toString());
		JSONObject jsonObject_con1 = (JSONObject) obj_con1;
		JSONArray host_components_con1 = (JSONArray) jsonObject_con1
				.get("host_components");
		JSONObject component_con1 = (JSONObject) host_components_con1.get(0);
		String url_con1 = (String) component_con1.get("href");
		if (proxy.equals("true")) {
			url_con1 = url_con1.replace("http", "https");
		}

		StringBuilder content1 = new setAmbariConnection()
				.getConnection(url_con1);

		JSONParser parser1 = new JSONParser();
		Object obj1 = parser1.parse(content1.toString());
		JSONObject jsonObject1 = (JSONObject) obj1;
		JSONObject metrics1 = (JSONObject) jsonObject1.get("metrics");
		JSONObject yarn = (JSONObject) metrics1.get("yarn");
		JSONObject clustermetrics = (JSONObject) yarn.get("ClusterMetrics");

		JSONObject appmetrics_queue = (JSONObject) yarn.get("Queue");
		JSONObject appmetrics_queue_root = (JSONObject) appmetrics_queue
				.get("root");

		long activeNMs = (Long) clustermetrics.get("NumActiveNMs");
		long decommNMs = (Long) clustermetrics.get("NumDecommissionedNMs");
		long lostNMs = (Long) clustermetrics.get("NumLostNMs");
		long rebootNMs = (Long) clustermetrics.get("NumRebootedNMs");
		long unhealthyNMs = (Long) clustermetrics.get("NumUnhealthyNMs");

		long active_apps = (Long) appmetrics_queue_root
				.get("ActiveApplications");
		long active_users = (Long) appmetrics_queue_root
				.get("ActiveApplications");
		long alloc_con = (Long) appmetrics_queue_root
				.get("AllocatedContainers");
		long alloc_mem = (Long) appmetrics_queue_root.get("AllocatedMB");
		long apps_completed = (Long) appmetrics_queue_root.get("AppsCompleted");
		long apps_failed = (Long) appmetrics_queue_root.get("AppsFailed");
		long apps_killed = (Long) appmetrics_queue_root.get("AppsKilled");
		long apps_pending = (Long) appmetrics_queue_root.get("AppsPending");
		long apps_running = (Long) appmetrics_queue_root.get("AppsRunning");
		long apps_submitted = (Long) appmetrics_queue_root.get("AppsSubmitted");
		long ava_mem = (Long) appmetrics_queue_root.get("AvailableMB");

		Rel_ser_metrics.put("NUM_ACTIVE_NMS", new Long((long) activeNMs));
		Rel_ser_metrics.put("NUM_DECOMMISSIONED_NMS",
				new Long((long) decommNMs));
		Rel_ser_metrics.put("NUM_LOST_NMS", new Long((long) lostNMs));
		Rel_ser_metrics.put("NUM_REBOOTED_NMS", new Long((long) rebootNMs));
		Rel_ser_metrics.put("NUM_UNHEALTHY_NMS", new Long((long) unhealthyNMs));

		Rel_ser_metrics.put("NUM_ACTIVE_APPS", new Long((long) active_apps));
		Rel_ser_metrics.put("NUM_ACTIVE_USERS", new Long((long) active_users));
		Rel_ser_metrics.put("ALLOC_CONT", new Long((long) alloc_con));
		Rel_ser_metrics.put("ALLOC_MEM", new Long((long) alloc_mem));
		Rel_ser_metrics.put("NUM_APPS_COMP", new Long((long) apps_completed));
		Rel_ser_metrics.put("NUM_APPS_FAILED", new Long((long) apps_failed));
		Rel_ser_metrics.put("NUM_APPS_KILLED", new Long((long) apps_killed));
		Rel_ser_metrics.put("NUM_APPS_PENDING", new Long((long) apps_pending));
		Rel_ser_metrics.put("NUM_APPS_RUNNING", new Long((long) apps_running));
		Rel_ser_metrics.put("NUM_APPS_SUBMITTED", new Long(
				(long) apps_submitted));
		Rel_ser_metrics.put("AVA_MEM", new Long((long) ava_mem));

		services ser_obj1 = new services();
		ser_obj1.setService("YARN", "Started", Rel_ser_metrics);
		rel_ser_metrics.add(ser_obj1);

	}

	public void setRelMetrics() throws SQLException {

		Calendar calendar = Calendar.getInstance();
		java.sql.Timestamp ourJavaTimestampObject = new java.sql.Timestamp(
				calendar.getTime().getTime());

		stmt = connection.createStatement();
		String sql;

		for (int i = 0; i < rel_ser_metrics.size(); i++) {

			int flag = 0;
			String sql1 = "select * from Reliability_Metrics where cluster_id=(select cluster_id from Cluster where cluster_name='"
					+ CLUSTER_NAME
					+ "') and metrics_group='"
					+ rel_ser_metrics.get(i).service_name + "'";
			ResultSet rs = stmt.executeQuery(sql1);
			while (rs.next()) {
				flag++;
			}

			if (flag == 0) {

				String sql2 = "select max(metrics_id) as count from Reliability_Metrics";
				ResultSet rs2 = stmt.executeQuery(sql2);
				while (rs2.next()) {
					Metrics_Id = rs2.getInt("count") + 1;
				}

				for (int j = 0; j < rel_ser_metrics.get(i).service_metrics
						.size(); j++) {

					sql = "INSERT INTO Reliability_Metrics VALUES ("
							+ Cluster_Id
							+ ","
							+ Metrics_Id
							+ ",'"
							+ rel_ser_metrics.get(i).service_metrics_name
									.get(j)
							+ "',"
							+ rel_ser_metrics.get(i).service_metrics
									.get(rel_ser_metrics.get(i).service_metrics_name
											.get(j)) + ",'"
							+ ourJavaTimestampObject + "'," + "'"
							+ rel_ser_metrics.get(i).service_name + "'" + ")";
					stmt.executeUpdate(sql);

					if (rel_ser_metrics.get(i).service_metrics_name.get(j)
							.equals("NUM_LOST_NMS")) {
						sql = "INSERT INTO NUM_LOST_NMS VALUES ("
								+ Cluster_Id
								+ ","
								+ rel_ser_metrics.get(i).service_metrics
										.get(rel_ser_metrics.get(i).service_metrics_name
												.get(j)) + ",'"
								+ ourJavaTimestampObject + "')";
						stmt.executeUpdate(sql);

					}

					Metrics_Id = Metrics_Id + 1;
				}
			}

			else {

				for (int j = 0; j < rel_ser_metrics.get(i).service_metrics
						.size(); j++) {
					sql = "Update Reliability_Metrics set metrics_value="
							+ rel_ser_metrics.get(i).service_metrics
									.get(rel_ser_metrics.get(i).service_metrics_name
											.get(j))
							+ ","
							+ "datetimestamp='"
							+ ourJavaTimestampObject
							+ "' where cluster_id=(select cluster_id from Cluster where cluster_name='"
							+ CLUSTER_NAME
							+ "') and metrics_name='"
							+ rel_ser_metrics.get(i).service_metrics_name
									.get(j) + "' and metrics_group='"
							+ rel_ser_metrics.get(i).service_name + "'";
					stmt.executeUpdate(sql);

					if (rel_ser_metrics.get(i).service_metrics_name.get(j)
							.equals("NUM_LOST_NMS")) {
						sql = "INSERT INTO NUM_LOST_NMS VALUES ("
								+ Cluster_Id
								+ ","
								+ rel_ser_metrics.get(i).service_metrics
										.get(rel_ser_metrics.get(i).service_metrics_name
												.get(j)) + ",'"
								+ ourJavaTimestampObject + "')";
						stmt.executeUpdate(sql);

					}
				}
			}

		}

	}

	// Performance metric collection
	public void getPerformanceMetricProperties() throws IOException,
			ParseException {

		StringBuilder content1_con1 = new setAmbariConnection()
				.getConnection(this.perf_url);
		System.out.println(this.perf_url + "--");
		JSONParser parser_con1 = new JSONParser();
		Object obj_con1 = parser_con1.parse(content1_con1.toString());
		JSONObject jsonObject_con1 = (JSONObject) obj_con1;
		JSONArray host_components_con1 = (JSONArray) jsonObject_con1
				.get("host_components");
		JSONObject component_con1 = (JSONObject) host_components_con1.get(0);
		String url_con1 = (String) component_con1.get("href");
		if (proxy.equals("true")) {
			url_con1 = url_con1.replace("http", "https");
		}
		// System.out.println(url_con1);
		StringBuilder content = new setAmbariConnection()
				.getConnection(url_con1);
		JSONParser parser = new JSONParser();
		Object obj = parser.parse(content.toString());
		JSONObject jsonObject = (JSONObject) obj;
		JSONObject metrics = (JSONObject) jsonObject.get("metrics");
		JSONObject yarn = (JSONObject) metrics.get("yarn");
		JSONObject queue = (JSONObject) yarn.get("Queue");

		JSONObject root = (JSONObject) queue.get("root");

		root.values();

		l2: for (int i = 0; i < root.size(); i++) {

			String key = root.keySet().toArray()[i].toString();

			if (key.equals("AppAttemptFirstContainerAllocationDelayAvgTime")) {
				continue l2;
			}

			JSONObject json_value;
			long value = 0;

			try {
				json_value = (JSONObject) root.values().toArray()[i];

				l1: for (int j = 0; j < json_value.size(); j++) {
					try {
						if (json_value.keySet().toArray()[j]
								.toString()
								.equals("AppAttemptFirstContainerAllocationDelayAvgTime")) {
							continue l1;
						}
						String key1 = key + ":"
								+ json_value.keySet().toArray()[j].toString();

						long value1 = new Long(
								json_value.values().toArray()[j].toString());

						System.out.println(key1 + "--" + value1);
						Perf_metrics.put(key1, value1);

					}

					catch (Exception e) {
						e.printStackTrace();
					}

				}
			}

			catch (Exception e) {

				value = new Long(root.values().toArray()[i].toString());
				Perf_metrics.put(key, value);

			}

		}

		services ser_obj1 = new services();
		ser_obj1.setService("yarn_perf", "Started", Perf_metrics);
		perf_ser_metrics.add(ser_obj1);
	}

	public void setPerfMetrics() throws SQLException {

		System.out.println("start coll");
		Calendar calendar = Calendar.getInstance();
		java.sql.Timestamp ourJavaTimestampObject = new java.sql.Timestamp(
				calendar.getTime().getTime());

		stmt = connection.createStatement();
		String sql;

		for (int i = 0; i < perf_ser_metrics.size(); i++) {

			int flag = 0;
			String sql1 = "select count(*) as cou from Performance_Metrics where cluster_id=(select cluster_id from Cluster where cluster_name='"
					+ CLUSTER_NAME
					+ "') and metrics_group='"
					+ perf_ser_metrics.get(i).service_name + "'";
			ResultSet rs = stmt.executeQuery(sql1);
			while (rs.next()) {
				flag = rs.getInt("cou");

			}

			if (flag == 0) {

				String sql2 = "select max(metrics_id) as count from Performance_Metrics";
				ResultSet rs2 = stmt.executeQuery(sql2);
				while (rs2.next()) {
					Metrics_Id = rs2.getInt("count") + 1;
				}

				for (int j = 0; j < perf_ser_metrics.get(i).service_metrics
						.size(); j++) {

					sql = "INSERT INTO Performance_Metrics VALUES ("
							+ Cluster_Id
							+ ","
							+ Metrics_Id
							+ ",'"
							+ perf_ser_metrics.get(i).service_metrics_name
									.get(j)
							+ "',"
							+ perf_ser_metrics.get(i).service_metrics
									.get(perf_ser_metrics.get(i).service_metrics_name
											.get(j)) + ",'"
							+ ourJavaTimestampObject + "'," + "'"
							+ perf_ser_metrics.get(i).service_name + "'" + ")";

					stmt.executeUpdate(sql);
					Metrics_Id = Metrics_Id + 1;
				}
			}

			else {

				for (int j = 0; j < perf_ser_metrics.get(i).service_metrics
						.size(); j++) {

					sql = "Update Performance_Metrics set metrics_value="
							+ perf_ser_metrics.get(i).service_metrics
									.get(perf_ser_metrics.get(i).service_metrics_name
											.get(j))
							+ ","
							+ "datetimestamp='"
							+ ourJavaTimestampObject
							+ "' where cluster_id=(select cluster_id from Cluster where cluster_name='"
							+ CLUSTER_NAME
							+ "') and metrics_name='"
							+ perf_ser_metrics.get(i).service_metrics_name
									.get(j) + "' and metrics_group='"
							+ perf_ser_metrics.get(i).service_name + "'";
					stmt.executeUpdate(sql);
				}
			}

		}

	}

	// Close connection
	public void closeConnection(Connection conn) throws SQLException {
		conn.close();
	}

	public void collectServiceMetadata(String url, ArrayList<String> pros)
			throws ParseException {
		StringBuilder content = new setAmbariConnection().getConnection(url);

		JSONParser parser = new JSONParser();
		Object obj = parser.parse(content.toString());
		JSONObject jsonObject = (JSONObject) obj;
		JSONArray items = (JSONArray) jsonObject.get("items");
		JSONObject ne = (JSONObject) items.get(0);
		String href = (String) ne.get("href");
		if (proxy.equals("true"))
			href = href.replace("http", "https");

		StringBuilder content1 = new setAmbariConnection().getConnection(href);

		JSONParser parser1 = new JSONParser();
		Object obj1 = parser1.parse(content1.toString());
		JSONObject jsonObject1 = (JSONObject) obj1;
		JSONArray items1 = (JSONArray) jsonObject1.get("items");
		JSONObject ne1 = (JSONObject) items1.get(0);

		JSONObject properties = (JSONObject) ne1.get("properties");
		for (int i = 0; i < pros.size(); i++) {
			String http = (String) properties.get(pros.get(i));

			servicemetadata.put(pros.get(i), http);
		}

	}

	public void collectComponentMetadata(String url, String service)
			throws ParseException {
		StringBuilder content = new setAmbariConnection().getConnection(url);

		JSONParser parser = new JSONParser();
		Object obj = parser.parse(content.toString());
		JSONObject jsonObject = (JSONObject) obj;
		JSONArray host_components = (JSONArray) jsonObject
				.get("host_components");

		for (int i = 0; i < host_components.size(); i++) {
			JSONObject ne = (JSONObject) host_components.get(i);
			JSONObject hostroles = (JSONObject) ne.get("HostRoles");
			String host_name = (String) hostroles.get("host_name");
			servicemetadata.put(service + "_hostname_" + i, host_name);

		}

	}

	public void setHDFSServiceMetadata(ArrayList<String> pros, String service)
			throws ParseException, SQLException {
		Map<String, String> meta = new HashMap<String, String>();

		String act = servicemetadata.get("dfs.namenode.http-address");
		String act_host = act.split(":")[0];
		String webport = act.split(":")[1];
		String std = servicemetadata.get("dfs.namenode.secondary.http-address");
		String std_host = std.split(":")[0];
		String port = servicemetadata.get("fs.defaultFS").split(":")[2];
		String act_url = "http://" + act_host + ":" + webport;
		String std_url = "http://" + std_host + ":" + webport;
		String ext_url = "https://" + service.toLowerCase() + "."
				+ DATA_CENTER.toLowerCase() + "." + CLUSTER_NAME.toLowerCase()
				+ ".symcpe.net/";

		meta.put("cluster_name", CLUSTER_NAME);
		meta.put("cluster_id", new Integer(Cluster_Id).toString());
		meta.put("service_name", "HDFS");
		meta.put("ext_url", ext_url);
		meta.put("ext_fqdn", "unknown");
		meta.put("ext_vip", "unknown");
		meta.put("int_act_url", act_url);
		meta.put("int_std_url", std_url);
		meta.put("act_host", act_host);
		meta.put("std_host", std_host);
		meta.put("port", port);
		meta.put("webport", webport);

		this.uploadServiceMetadata(meta);

	}

	public void setResourceManagerServiceMetadata(ArrayList<String> pros,
			String service) throws ParseException, SQLException {
		Map<String, String> meta = new HashMap<String, String>();

		String act = servicemetadata.get(pros.get(0));
		String act_host = act.split(":")[0];
		String webport = act.split(":")[1];

		String std_host = "";
		String port = servicemetadata.get(pros.get(0)).split(":")[1];
		String act_url = "http://" + act_host + ":" + webport;
		String std_url = "";
		String ext_url = "https://" + service.toLowerCase() + "."
				+ DATA_CENTER.toLowerCase() + "." + CLUSTER_NAME.toLowerCase()
				+ ".symcpe.net/";

		meta.put("cluster_name", CLUSTER_NAME);
		meta.put("cluster_id", new Integer(Cluster_Id).toString());
		meta.put("service_name", service);
		meta.put("ext_url", ext_url);
		meta.put("ext_fqdn", "unknown");
		meta.put("ext_vip", "unknown");
		meta.put("int_act_url", act_url);
		meta.put("int_std_url", std_url);
		meta.put("act_host", act_host);
		meta.put("std_host", std_host);
		meta.put("port", port);
		meta.put("webport", webport);

		this.uploadServiceMetadata(meta);

	}

	public void setHiveServiceMetadata(ArrayList<String> pros, String service)
			throws ParseException, SQLException {
		Map<String, String> meta = new HashMap<String, String>();

		String act = servicemetadata.get(pros.get(0));
		String act_host = act.split(":")[1].replaceAll("//", "");
		String webport = servicemetadata.get(pros.get(1));

		String std_host = "";
		String port = servicemetadata.get(pros.get(0)).split(":")[2];
		String act_url = servicemetadata.get(pros.get(0));
		String std_url = "";
		String ext_url = "https://" + service.toLowerCase() + "."
				+ DATA_CENTER.toLowerCase() + "." + CLUSTER_NAME.toLowerCase()
				+ ".symcpe.net/";

		meta.put("cluster_name", CLUSTER_NAME);
		meta.put("cluster_id", new Integer(Cluster_Id).toString());
		meta.put("service_name", service);
		meta.put("ext_url", ext_url);
		meta.put("ext_fqdn", "unknown");
		meta.put("ext_vip", "unknown");
		meta.put("int_act_url", act_url);
		meta.put("int_std_url", std_url);
		meta.put("act_host", act_host);
		meta.put("std_host", std_host);
		meta.put("port", port);
		meta.put("webport", webport);

		this.uploadServiceMetadata(meta);

	}

	public void setOozieServiceMetadata(ArrayList<String> pros, String service)
			throws ParseException, SQLException {
		Map<String, String> meta = new HashMap<String, String>();

		String act = servicemetadata.get(pros.get(0));
		String act_host = act.split(":")[1].replaceAll("//", "");
		String webport = servicemetadata.get(pros.get(0)).split(":")[2]
				.split("/")[0];

		String std_host = "";
		String port = webport;
		String act_url = servicemetadata.get(pros.get(0));
		String std_url = "";
		String ext_url = "https://" + service.toLowerCase() + "."
				+ DATA_CENTER.toLowerCase() + "." + CLUSTER_NAME.toLowerCase()
				+ ".symcpe.net/";

		meta.put("cluster_name", CLUSTER_NAME);
		meta.put("cluster_id", new Integer(Cluster_Id).toString());
		meta.put("service_name", service);
		meta.put("ext_url", ext_url);
		meta.put("ext_fqdn", "unknown");
		meta.put("ext_vip", "unknown");
		meta.put("int_act_url", act_url);
		meta.put("int_std_url", std_url);
		meta.put("act_host", act_host);
		meta.put("std_host", std_host);
		meta.put("port", port);
		meta.put("webport", webport);

		this.uploadServiceMetadata(meta);

	}

	public void setHbaseServiceMetadata(ArrayList<String> pros, String service)
			throws ParseException, SQLException {
		Map<String, String> meta = new HashMap<String, String>();

		String act_host = servicemetadata.get("HBASE_hostname_0");
		String webport = servicemetadata.get(pros.get(0));
		String std_host = servicemetadata.get("HBASE_hostname_1");
		String port = servicemetadata.get(pros.get(1));
		String act_url = "http://" + act_host + ":" + webport;
		String std_url = "http://" + std_host + ":" + webport;
		String ext_url = "https://" + service.toLowerCase() + "."
				+ DATA_CENTER.toLowerCase() + "." + CLUSTER_NAME.toLowerCase()
				+ ".symcpe.net/";

		meta.put("cluster_name", CLUSTER_NAME);
		meta.put("cluster_id", new Integer(Cluster_Id).toString());
		meta.put("service_name", service);
		meta.put("ext_url", ext_url);
		meta.put("ext_fqdn", "unknown");
		meta.put("ext_vip", "unknown");
		meta.put("int_act_url", act_url);
		meta.put("int_std_url", std_url);
		meta.put("act_host", act_host);
		meta.put("std_host", std_host);
		meta.put("port", port);
		meta.put("webport", webport);

		this.uploadServiceMetadata(meta);

	}

	public void setStormServiceMetadata(ArrayList<String> pros, String service)
			throws ParseException, SQLException {
		Map<String, String> meta = new HashMap<String, String>();

		String act_host = servicemetadata.get("STORM_hostname_0");
		String webport = servicemetadata.get(pros.get(0));
		String std_host = "";
		String port = webport;
		String act_url = "http://" + act_host + ":" + webport;
		String std_url = "";
		String ext_url = "https://" + service.toLowerCase() + "."
				+ DATA_CENTER.toLowerCase() + "." + CLUSTER_NAME.toLowerCase()
				+ ".symcpe.net/";

		meta.put("cluster_name", CLUSTER_NAME);
		meta.put("cluster_id", new Integer(Cluster_Id).toString());
		meta.put("service_name", service);
		meta.put("ext_url", ext_url);
		meta.put("ext_fqdn", "unknown");
		meta.put("ext_vip", "unknown");
		meta.put("int_act_url", act_url);
		meta.put("int_std_url", std_url);
		meta.put("act_host", act_host);
		meta.put("std_host", std_host);
		meta.put("port", port);
		meta.put("webport", webport);

		this.uploadServiceMetadata(meta);

	}

	public void setFalconServiceMetadata(ArrayList<String> pros, String service)
			throws ParseException, SQLException {
		Map<String, String> meta = new HashMap<String, String>();

		String act_host = servicemetadata.get("FALCON_hostname_0");
		String webport = servicemetadata.get(pros.get(0));
		String std_host = "";
		String port = servicemetadata.get(pros.get(0));
		;
		String act_url = "http://" + act_host + ":" + webport;
		String std_url = "";
		String ext_url = "https://" + service.toLowerCase() + "."
				+ DATA_CENTER.toLowerCase() + "." + CLUSTER_NAME.toLowerCase()
				+ ".symcpe.net/";

		meta.put("cluster_name", CLUSTER_NAME);
		meta.put("cluster_id", new Integer(Cluster_Id).toString());
		meta.put("service_name", service);
		meta.put("ext_url", ext_url);
		meta.put("ext_fqdn", "unknown");
		meta.put("ext_vip", "unknown");
		meta.put("int_act_url", act_url);
		meta.put("int_std_url", std_url);
		meta.put("act_host", act_host);
		meta.put("std_host", std_host);
		meta.put("port", port);
		meta.put("webport", webport);

		this.uploadServiceMetadata(meta);

	}

	public void setRangerServiceMetadata(ArrayList<String> pros, String service)
			throws ParseException, SQLException {
		Map<String, String> meta = new HashMap<String, String>();

		String act_host = servicemetadata.get("RANGER_hostname_0");
		String webport = servicemetadata.get(pros.get(0));
		String std_host = "";
		String port = servicemetadata.get(pros.get(0));
		;
		String act_url = "http://" + act_host + ":" + webport;
		String std_url = "";
		String ext_url = "https://" + service.toLowerCase() + "."
				+ DATA_CENTER.toLowerCase() + "." + CLUSTER_NAME.toLowerCase()
				+ ".symcpe.net/";

		meta.put("cluster_name", CLUSTER_NAME);
		meta.put("cluster_id", new Integer(Cluster_Id).toString());
		meta.put("service_name", service);
		meta.put("ext_url", ext_url);
		meta.put("ext_fqdn", "unknown");
		meta.put("ext_vip", "unknown");
		meta.put("int_act_url", act_url);
		meta.put("int_std_url", std_url);
		meta.put("act_host", act_host);
		meta.put("std_host", std_host);
		meta.put("port", port);
		meta.put("webport", webport);

		this.uploadServiceMetadata(meta);

	}

	public void setSparkServiceMetadata(ArrayList<String> pros, String service)
			throws ParseException, SQLException {
		Map<String, String> meta = new HashMap<String, String>();

		String act_host = servicemetadata.get("SPARK_hostname_0");
		String webport = servicemetadata.get(pros.get(0));
		String std_host = "";
		String port = servicemetadata.get(pros.get(0));
		;
		String act_url = "http://" + act_host + ":" + webport;
		String std_url = "";
		String ext_url = "https://" + service.toLowerCase() + "."
				+ DATA_CENTER.toLowerCase() + "." + CLUSTER_NAME.toLowerCase()
				+ ".symcpe.net/";

		meta.put("cluster_name", CLUSTER_NAME);
		meta.put("cluster_id", new Integer(Cluster_Id).toString());
		meta.put("service_name", service);
		meta.put("ext_url", ext_url);
		meta.put("ext_fqdn", "unknown");
		meta.put("ext_vip", "unknown");
		meta.put("int_act_url", act_url);
		meta.put("int_std_url", std_url);
		meta.put("act_host", act_host);
		meta.put("std_host", std_host);
		meta.put("port", port);
		meta.put("webport", webport);

		this.uploadServiceMetadata(meta);

	}

	public void uploadServiceMetadata(Map<String, String> s)
			throws SQLException {
		Calendar calendar = Calendar.getInstance();
		java.sql.Timestamp ourJavaTimestampObject = new java.sql.Timestamp(
				calendar.getTime().getTime());

		stmt = connection.createStatement();
		String sql, sql2;

		int flag = 0;
		String sql1 = "select count(*) as cou from servicemetadata where cluster_id=(select cluster_id from Cluster where cluster_name='"
				+ CLUSTER_NAME
				+ "') and service_name='"
				+ s.get("service_name") + "'";
		ResultSet rs = stmt.executeQuery(sql1);
		while (rs.next()) {
			flag = rs.getInt("cou");
		}

		if (flag == 0) {

			sql = "insert into servicemetadata values ("
					+ new Integer(s.get("cluster_id")) + ",'"
					+ s.get("cluster_name") + "','" + s.get("service_name")
					+ "','" + s.get("ext_url") + "','" + s.get("ext_fqdn")
					+ "','" + s.get("ext_vip") + "','" + s.get("int_act_url")
					+ "','" + s.get("act_host") + "','" + s.get("int_std_url")
					+ "','" + s.get("std_host") + "','"
					+ new Integer(s.get("port")) + "','"
					+ new Integer(s.get("webport")) + "','"
					+ ourJavaTimestampObject + "')";

			sql2 = "insert into servicemetadata values ("
					+ new Integer(s.get("cluster_id")) + ",'"
					+ s.get("cluster_name") + "','" + "AMBARI" + "','" + ""
					+ "','" + "" + "','" + "" + "','" + serverName + "','" + ""
					+ "','" + "" + "','" + "" + "','" + 8080 + "','" + 8080
					+ "','" + ourJavaTimestampObject + "')";

		} else {
			sql = "update servicemetadata set cluster_id="
					+ new Integer(s.get("cluster_id")) + ",cluster_name='"
					+ s.get("cluster_name") + "',service_name='"
					+ s.get("service_name") + "',ext_url='" + s.get("ext_url")
					+ "',ext_fqdn='" + s.get("ext_fqdn") + "',ext_vip='"
					+ s.get("ext_vip") + "',int_act_url='"
					+ s.get("int_act_url") + "',act_hostname='"
					+ s.get("act_host") + "',int_std_url='"
					+ s.get("int_std_url") + "',std_hostname='"
					+ s.get("std_host") + "',port='"
					+ new Integer(s.get("port")) + "',webport='"
					+ new Integer(s.get("webport")) + "',datetimestamp='"
					+ ourJavaTimestampObject + "' " + "where cluster_id ="
					+ new Integer(s.get("cluster_id")) + " and service_name='"
					+ s.get("service_name") + "'";

			sql2 = "insert into servicemetadata values ("
					+ new Integer(s.get("cluster_id")) + ",'"
					+ s.get("cluster_name") + "','" + "AMBARI" + "','" + ""
					+ "','" + "" + "','" + "" + "','" + serverName + "','" + ""
					+ "','" + "" + "','" + "" + "','" + 8080 + "','" + 8080
					+ "','" + ourJavaTimestampObject + "')";

		}
		stmt.executeUpdate(sql);

		stmt.executeUpdate(sql2);

	}

	public void getHostComponents(String url) throws ParseException,
			SQLException {

		Calendar calendar = Calendar.getInstance();
		java.sql.Timestamp ourJavaTimestampObject = new java.sql.Timestamp(
				calendar.getTime().getTime());

		stmt = connection.createStatement();
		String sql1 = "delete from Host_Components where cluster_id="
				+ new Integer(Cluster_Id);
		stmt.executeUpdate(sql1);
		StringBuilder content = new setAmbariConnection().getConnection(url);
		JSONParser parser = new JSONParser();
		Object obj = parser.parse(content.toString());
		JSONObject jsonObject = (JSONObject) obj;
		JSONArray firstName = (JSONArray) jsonObject.get("items");
		for (int i = 0; i < firstName.size(); i++) {
			JSONObject ne = (JSONObject) firstName.get(i);
			String href = (String) ne.get("href");
			if (proxy.equals("true"))
				href = href.replace("http", "https");
			StringBuilder content1 = new setAmbariConnection()
					.getConnection(href);

			JSONParser parser1 = new JSONParser();
			Object obj1 = parser1.parse(content1.toString());
			JSONObject jsonObject1 = (JSONObject) obj1;
			JSONArray components = (JSONArray) jsonObject1.get("components");

			for (int j = 0; j < components.size(); j++) {
				JSONObject ne1 = (JSONObject) components.get(j);
				JSONObject ServiceComponentInfo = (JSONObject) ne1
						.get("ServiceComponentInfo");
				String href2 = (String) ne1.get("href");
				String s = (String) ServiceComponentInfo.get("component_name");

				if (proxy.equals("true"))
					href2 = href2.replace("http", "https");
				StringBuilder content2 = new setAmbariConnection()
						.getConnection(href2);

				JSONParser parser2 = new JSONParser();
				Object obj2 = parser2.parse(content2.toString());
				JSONObject jsonObject2 = (JSONObject) obj2;
				JSONArray host_components = (JSONArray) jsonObject2
						.get("host_components");
				for (int k = 0; k < host_components.size(); k++) {
					JSONObject ne2 = (JSONObject) host_components.get(k);
					JSONObject HostRoles = (JSONObject) ne2.get("HostRoles");
					String s3 = (String) HostRoles.get("host_name");

					String sql;

					sql = "insert into Host_Components values ("
							+ new Integer(Cluster_Id) + ",'" + CLUSTER_NAME
							+ "','" + s + "','" + s3 + "','"
							+ ourJavaTimestampObject + "')";

					// System.out.println(sql);
					stmt.executeUpdate(sql);

				}
			}

		}
	}

	public void uploadHostComponentMetadata(Map<String, String> s,
			ArrayList<String> s1) throws SQLException {
		Calendar calendar = Calendar.getInstance();
		java.sql.Timestamp ourJavaTimestampObject = new java.sql.Timestamp(
				calendar.getTime().getTime());

		stmt = connection.createStatement();
		String sql1 = "delete from Host_Components where cluster_id="
				+ new Integer(Cluster_Id);
		stmt.executeUpdate(sql1);
		for (int i = 0; i < s1.size(); i++) {

			String sql;

			sql = "insert into Host_Components values ("
					+ new Integer(Cluster_Id) + ",'" + CLUSTER_NAME + "','"
					+ s1.get(i) + "','" + s.get(s1.get(i)) + "','"
					+ ourJavaTimestampObject + "')";

			stmt.executeUpdate(sql);
		}

	}

	public void getHostStatus(String url) throws ParseException, SQLException {
		ArrayList<String> lh = new ArrayList<String>();
		Calendar calendar = Calendar.getInstance();
		java.sql.Timestamp ourJavaTimestampObject = new java.sql.Timestamp(
				calendar.getTime().getTime());

		// stmt = connection.createStatement();
		// String sql1 = "delete from Host_Status where cluster_id="
		// + new Integer(Cluster_Id);
		// stmt.executeUpdate(sql1);
		StringBuilder content = new setAmbariConnection().getConnection(url);
		JSONParser parser = new JSONParser();
		Object obj = parser.parse(content.toString());
		JSONObject jsonObject = (JSONObject) obj;
		JSONArray firstName = (JSONArray) jsonObject.get("items");
		l3: for (int i = 0; i < firstName.size(); i++) {
			JSONObject ne = (JSONObject) firstName.get(i);
			String href = (String) ne.get("href");
			// System.out.println(href);
			if (proxy.equals("true"))
				href = href.replace("http", "https");
			StringBuilder content1 = new setAmbariConnection()
					.getConnection(href);
			try {
				JSONParser parser1 = new JSONParser();
				Object obj1 = parser1.parse(content1.toString());
				JSONObject jsonObject1 = (JSONObject) obj1;

				JSONObject ne1 = (JSONObject) jsonObject1.get("Hosts");

				String host_name = (String) ne1.get("host_name");
				String status = (String) ne1.get("host_status");
				String state = (String) ne1.get("host_state");
				System.out.println(host_name + "---" + status + "---" + state);
				if (state.equals("HEARTBEAT_LOST")) {
					System.out.println(host_name + "---" + status + "---"
							+ state);
					lh.add(host_name);
				}

			}

			catch (Exception e) {
				i--;
				System.out.println(href);
				continue l3;
			}
		}

		email.sendmail(CLUSTER_NAME, lh, serverName, email_id);
	}

	public void setServiceMetaData() throws ParseException, SQLException {
		// System.out.println("servcie met");
		// hdfs metadata
		ArrayList<String> hdfsprops = new ArrayList<String>();
		String hdfsurl = serverName + "/api/v1/clusters/" + CLUSTER_NAME
				+ "/configurations?type=hdfs-site";
		String coreurl = serverName + "/api/v1/clusters/" + CLUSTER_NAME
				+ "/configurations?type=core-site";
		hdfsprops.add("dfs.namenode.http-address");
		hdfsprops.add("dfs.namenode.secondary.http-address");
		this.collectServiceMetadata(hdfsurl, hdfsprops);
		ArrayList<String> coreprops = new ArrayList<String>();
		coreprops.add("fs.defaultFS");
		this.collectServiceMetadata(coreurl, coreprops);
		this.setHDFSServiceMetadata(hdfsprops, "HDFS");

		// RM metadata
		String rmurl = serverName + "/api/v1/clusters/" + CLUSTER_NAME
				+ "/configurations?type=yarn-site";
		ArrayList<String> yarnprops = new ArrayList<String>();
		yarnprops.add("yarn.resourcemanager.webapp.address");
		yarnprops.add("yarn.resourcemanager.address");
		this.collectServiceMetadata(rmurl, yarnprops);
		this.setResourceManagerServiceMetadata(yarnprops, "YARN");

		// Mapred metadata
		String mrurl = serverName + "/api/v1/clusters/" + CLUSTER_NAME
				+ "/configurations?type=mapred-site";
		ArrayList<String> mrprops = new ArrayList<String>();
		mrprops.add("mapreduce.jobhistory.webapp.address");
		mrprops.add("mapreduce.jobhistory.address");
		this.collectServiceMetadata(mrurl, mrprops);
		this.setResourceManagerServiceMetadata(mrprops, "MAPREDUCE");

		// Hive metadata
		String hiveurl = serverName + "/api/v1/clusters/" + CLUSTER_NAME
				+ "/configurations?type=hive-site";
		ArrayList<String> hiveprops = new ArrayList<String>();
		hiveprops.add("hive.metastore.uris");
		hiveprops.add("hive.server2.thrift.port");

		this.collectServiceMetadata(hiveurl, hiveprops);
		this.setHiveServiceMetadata(hiveprops, "HIVE");

		// Oozie metadata
		String oozieurl = serverName + "/api/v1/clusters/" + CLUSTER_NAME
				+ "/configurations?type=oozie-site";
		ArrayList<String> oozieprops = new ArrayList<String>();
		oozieprops.add("oozie.base.url");
		this.collectServiceMetadata(oozieurl, oozieprops);
		this.setOozieServiceMetadata(oozieprops, "OOZIE");

		// HBASE metadata
		if (ambariVersion.equals("2.0")) {

			String hbaseurl = serverName + "/api/v1/clusters/" + CLUSTER_NAME
					+ "/configurations?type=hbase-site";
			String hbasecomurl = serverName + "/api/v1/clusters/"
					+ CLUSTER_NAME + "/services/HBASE/components/HBASE_MASTER";
			ArrayList<String> hbaseprops = new ArrayList<String>();
			hbaseprops.add("hbase.master.info.port");
			hbaseprops.add("hbase.master.port");
			this.collectServiceMetadata(hbaseurl, hbaseprops);
			this.collectComponentMetadata(hbasecomurl, "HBASE");
			this.setHbaseServiceMetadata(hbaseprops, "HBASE");
		}

		// STORM metadata
		if (ambariVersion.equals("2.0")) {
			String stormurl = serverName + "/api/v1/clusters/" + CLUSTER_NAME
					+ "/configurations?type=storm-site";
			String stormcomurl = serverName + "/api/v1/clusters/"
					+ CLUSTER_NAME
					+ "/services/STORM/components/STORM_UI_SERVER";
			ArrayList<String> stormprops = new ArrayList<String>();
			stormprops.add("ui.port");
			this.collectServiceMetadata(stormurl, stormprops);
			this.collectComponentMetadata(stormcomurl, "STORM");
			this.setStormServiceMetadata(stormprops, "STORM");
		}

		// FALCON metadata
		if (ambariVersion.equals("2.0")) {
			String falconurl = serverName + "/api/v1/clusters/" + CLUSTER_NAME
					+ "/configurations?type=falcon-env";
			String falconcomurl = serverName + "/api/v1/clusters/"
					+ CLUSTER_NAME
					+ "/services/FALCON/components/FALCON_SERVER";
			ArrayList<String> falconprops = new ArrayList<String>();
			falconprops.add("falcon_port");
			falconprops.add("falcon.emeddedmq.port");
			this.collectServiceMetadata(falconurl, falconprops);
			this.collectComponentMetadata(falconcomurl, "FALCON");
			this.setFalconServiceMetadata(falconprops, "FALCON");
		}

		// RANGER metadata
		if (ambariVersion.equals("2.0")) {
			String rangerurl = serverName + "/api/v1/clusters/" + CLUSTER_NAME
					+ "/configurations?type=ranger-site";
			String rangercomurl = serverName + "/api/v1/clusters/"
					+ CLUSTER_NAME + "/services/RANGER/components/RANGER_ADMIN";
			ArrayList<String> rangerprops = new ArrayList<String>();
			rangerprops.add("HTTP_SERVICE_PORT");

			this.collectServiceMetadata(rangerurl, rangerprops);
			this.collectComponentMetadata(rangercomurl, "RANGER");
			this.setRangerServiceMetadata(rangerprops, "RANGER");
		}

		// SPARK metadata
		if (ambariVersion.equals("2.0")) {
			String sparkurl = serverName + "/api/v1/clusters/" + CLUSTER_NAME
					+ "/configurations?type=spark-defaults";
			String sparkcomurl = serverName + "/api/v1/clusters/"
					+ CLUSTER_NAME
					+ "/services/SPARK/components/SPARK_JOBHISTORYSERVER";
			ArrayList<String> sparkprops = new ArrayList<String>();
			sparkprops.add("spark.history.ui.port");

			this.collectServiceMetadata(sparkurl, sparkprops);
			this.collectComponentMetadata(sparkcomurl, "SPARK");
			this.setSparkServiceMetadata(sparkprops, "SPARK");
		}

		// --------------------------------------------------------------------------------------------------------------------------------------------
		this.getHostComponents(serverName + "/api/v1/clusters/" + CLUSTER_NAME
				+ "/services");
	}

	public void setIDCMetrics(Map m, String p) throws SQLException,
			java.text.ParseException {

		// System.out.println(p);
		Calendar calendar = Calendar.getInstance();
		java.sql.Timestamp ourJavaTimestampObject = new java.sql.Timestamp(
				calendar.getTime().getTime());
		Statement stmt = connection.createStatement();
		String sql = "delete from idc_disk_usage where cluster_id="
				+ new Integer(Cluster_Id) + " and path='" + p + "'";
		// System.out.println(sql);
		stmt.executeUpdate(sql);
		// String sql1;

		Iterator it = m.entrySet().iterator();
		while (it.hasNext()) {
			Map.Entry pair = (Map.Entry) it.next();
			System.out.println(pair.getKey() + " = " + pair.getValue());
			String sql1 = "insert into idc_disk_usage values ("
					+ new Integer(Cluster_Id) + ",'" + CLUSTER_NAME + "','" + p
					+ "','" + pair.getKey().toString() + "','"
					+ pair.getValue().toString().split(" ")[0] + "','"
					+ pair.getValue().toString().split(" ")[1] + "','"
					+ ourJavaTimestampObject + "')";

			setIDCGrafanaMetrics(Cluster_Id, CLUSTER_NAME, p, pair.getKey()
					.toString(), pair.getValue().toString().split(" ")[0], pair
					.getValue().toString().split(" ")[1]);

			stmt.executeUpdate(sql1);
		}

	}

	public void createInfluxDB() {
		InfluxDB influxDB = InfluxDBFactory.connect(influxDB_URL, influxDB_uid,
				influxDB_pass);
		influxDB.createDatabase(influxDB_database);

	}

	public void setIDCGrafanaMetrics(int cluster_id, String cluster_name,
			String p, String key, String value, String se) throws SQLException,
			java.text.ParseException {
		InfluxDB influxDB = InfluxDBFactory.connect(influxDB_URL, influxDB_uid,
				influxDB_pass);

		String dbName = influxDB_database;

		BatchPoints batchPoints = BatchPoints.database(dbName)
				.tag("async", "true").retentionPolicy("default")
				.consistency(ConsistencyLevel.ALL).build();

		long time1 = System.currentTimeMillis();
		for (int i = 0; i < idc_partition_name.split(",").length; i++) {
			if (key.contains(idc_partition_name.split(",")[i])) {
				key = key.split("=")[1];
				SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd"); // Month.Day.Year

				Date d = formatter.parse(key);
				time1 = d.getTime();
				// System.out.println(time1);
			}
		}

		String indbtable[] = p.split("/");
		String ind = indbtable[indbtable.length - 1];

		Point point1 = Point.measurement("idc_" + cluster_id + ind)
				.time(time1, TimeUnit.MILLISECONDS)
				.field("cluster_id", cluster_id)
				.field("cluster_name", cluster_name).field("path", p)
				.field("subdir", key)
				.field("space_occupied", new Double(value)).field("unit", se)
				.build();

		batchPoints.point(point1);

		influxDB.write(batchPoints);
	}

	public void deleteInfluxDB() {

		InfluxDB influxDB = InfluxDBFactory.connect(influxDB_URL, influxDB_uid,
				influxDB_pass);
		influxDB.deleteDatabase(influxDB_database);

	}

	// Main function
	public static void main(String[] args) throws IOException, ParseException,
			SQLException, ParserConfigurationException, SAXException,
			URISyntaxException, java.text.ParseException {

		String dashboard_path = System.getProperty("dashboard.confpath");

		conf = CollectConfiguration.getConf(dashboard_path);

		// Configurations
		CollectionAgent iniobj = new CollectionAgent("ClusterInitialization");
		uid = conf.get("dashboard.ambari.uid");
		password = conf.get("dashboard.ambari.password");
		setAmbariConnection.setCred(uid, password);

		serverName = conf.get("dashboard.ambari.server.url");
		datacenter = conf.get("dashboard.datacenter");
		proxy = conf.get("dashboard.proxy");
		ambariVersion = conf.get("dashboard.ambari.version");
		sqlhost = conf.get("dashboard.sql.hostname");
		port = conf.get("dashboard.sql.port");
		database = conf.get("dashboard.sql.database");
		sqluid = conf.get("dashboard.sql.username");
		sqlpass = conf.get("dashboard.sql.password");
		idcpath = conf.get("dashboard.cluster.hdfs.path");
		units = conf.get("dashboard.cluster.size.flag");
		webhdfsuri = conf.get("dashboard.cluster.webhdfs.uri");
		arpfreq = new Long(conf.get("dashboard.arp.metrics.frequency"));
		servicefreq = new Long(conf.get("dashboard.service.info.frequency"));
		pumafreq = new Long(conf.get("dashboard.puma.metrics.frequency"));
		pumaenable = new Boolean(conf.get("dashboard.puma.metrics.enable"));
		influxDB_URL = conf.get("dashboard.influxdb.url");
		influxDB_uid = conf.get("dashboard.influxdb.username");
		influxDB_pass = conf.get("dashboard.influxdb.password");
		influxDB_database = conf.get("dashboard.influxdb.database");
		idc_partition_name = conf.get("dashboard.idc.partition.name");
		idcenable = new Boolean(conf.get("dashboard.idc.metrics.enable"));
		idcfreq = new Long(conf.get("dashboard.idc.metrics.frequency"));
		avametcomponents = conf.get("dashboard.ava.metrics.components");
		email_id = conf.get("dashboard.alerts.emailid");

		iniobj.setConnection();
		iniobj.initCluster();

		iniobj.closeConnection(iniobj.connection);

		CollectionAgent avacrossobj = new CollectionAgent("Avacross");
		avacrossobj.ava_url = iniobj.ava_url;

		CollectionAgent avaobj = new CollectionAgent("Ava");
		avaobj.ava_url = iniobj.ava_url;
		avaobj.ava_url1 = iniobj.ava_url1;

		CollectionAgent relobj = new CollectionAgent("Rel");
		relobj.rel_url = iniobj.rel_url;
		relobj.rel_url1 = iniobj.rel_url1;

		CollectionAgent perfobj = new CollectionAgent("Per");
		perfobj.perf_url = iniobj.perf_url;

		CollectionAgent serviceobj = new CollectionAgent("Service");

		if (idcenable) {

			CollectionAgent idcjob = new CollectionAgent("Idc");
			idcjob.start();
		}

		avacrossobj.start();
		serviceobj.start();
		avaobj.start();
		relobj.start();
		perfobj.start();

		if (pumaenable) {

			CollectionAgent pumaobj = new CollectionAgent("Puma");
			pumaobj.start();
		}

	}

	// Run Thread
	public void run() {

		if (this.threadName.equals("Ava")) {
			while (true) {

				try {

					this.setConnection();
					this.getAvailableMetricProperties();
					this.setAvaMetrics();
					this.closeConnection(this.connection);

					Thread.sleep(arpfreq);

				}

				catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (InterruptedException e) { // TODO Auto-generated catch
													// block
					e.printStackTrace();
				} catch (Exception e) {
					e.printStackTrace();
				} finally {
					try {
						this.closeConnection(this.connection);
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

				}
			}
		}

		else if (this.threadName.equals("Avacross")) {
			while (true) {

				try {

					this.setConnection();
					this.getAvailableCrossMetricProperties();
					this.setAvaCrossMetrics();
					this.closeConnection(this.connection);

					Thread.sleep(arpfreq);

				}

				catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (InterruptedException e) { // TODO Auto-generated catch
													// block
					e.printStackTrace();
				} catch (Exception e) {
					e.printStackTrace();
				} finally {
					try {
						this.closeConnection(this.connection);
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

				}
			}
		} else if (this.threadName.equals("Rel")) {
			while (true) {
				try {

					this.setConnection();

					this.getReliabitityMetricProperties();

					this.setRelMetrics();
					this.closeConnection(this.connection);

					Thread.sleep(arpfreq);

				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (InterruptedException e) { // TODO Auto-generated catch
													// block
					e.printStackTrace();
				} catch (Exception e) {
					e.printStackTrace();
				} finally {
					try {
						this.closeConnection(this.connection);
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

				}
			}
		}

		else if (this.threadName.equals("Per")) {
			while (true) {
				try {

					this.setConnection();
					System.out.println("started");
					// this.perf_conn = this.getConn(perf_url);
					this.getPerformanceMetricProperties();

					this.setPerfMetrics();
					System.out.println("endeded");
					this.closeConnection(this.connection);

					Thread.sleep(arpfreq);
					// this.perf_conn.disconnect();

					// Thread.sleep(120000);

				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (InterruptedException e) { // TODO Auto-generated catch
													// block
					e.printStackTrace();
				} catch (Exception e) {
				} finally {
					try {
						this.closeConnection(this.connection);
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

				}
			}
		} else if (this.threadName.equals("Service")) {
			while (true) {
				try {

					this.setConnection();

					this.setServiceMetaData();
					// this.getHostStatus(ser_url);
					this.closeConnection(this.connection);

					Thread.sleep(servicefreq);
					// this.perf_conn.disconnect();

					// Thread.sleep(120000);

				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (InterruptedException e) { // TODO Auto-generated catch
													// block
					e.printStackTrace();
				} catch (Exception e) {
				} finally {
					try {
						this.closeConnection(this.connection);
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

				}
			}

		}

		else if (this.threadName.equals("Puma")) {
			while (true) {
				try {

					PumaMetricsCollectionAgent pumaobj = new PumaMetricsCollectionAgent();
					pumaobj.startPuma(conf, Cluster_Id);

					Thread.sleep(pumafreq);

				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (InterruptedException e) { // TODO Auto-generated catch
													// block
					e.printStackTrace();
				} catch (Exception e) {
				}
			}

		} else if (this.threadName.equals("Idc")) {
			while (true) {
				try {

					this.setConnection();
					this.initCluster();
					this.deleteInfluxDB();
					this.createInfluxDB();
					idcstats obj = new idcstats();
					String id_paths[] = idcpath.split(",");
					for (int i = 0; i < id_paths.length; i++) {
						String hdfs_path = webhdfsuri + id_paths[i];
						System.out.println(hdfs_path + "--" + units);
						Map<String, String> idc = obj.getIDCStats(hdfs_path,
								new Boolean(units));
						System.out.println(idc.size() + "got size");
						this.setIDCMetrics(idc, id_paths[i]);
					}

					Thread.sleep(idcfreq);

				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (InterruptedException e) { // TODO Auto-generated catch
													// block
					e.printStackTrace();
				} catch (Exception e) {
				}
			}

		}

	}

	// TODO Auto-generated method stub

	// Start Thread
	public void start() {

		if (t == null) {
			t = new Thread(this, this.threadName);
			t.start();
		}
	}

}
