// File Name SendHTMLEmail.java
package org.symantec.metrics.dashboard;
import java.util.*;

import javax.mail.*;
import javax.mail.internet.*;
import javax.activation.*;

import java.net.Socket;

public class email
{
   public static void sendmail(String cluster_name,ArrayList<String> host_names,String url,String email_id)
   {
      
      // Recipient's email ID needs to be mentioned.
      String to = email_id;

      // Sender's email ID needs to be mentioned
      String from = "queryx_noreply@symantec.com";

      // Assuming you are sending email from localhost
      String host = "smtp.ash2.symcpe.net";

      // Get system properties
      Properties properties = System.getProperties();

      // Setup mail server
      properties.setProperty("mail.smtp.host", host);

      // Get the default Session object.
      Session session = Session.getDefaultInstance(properties);

      try{
         // Create a default MimeMessage object.
         MimeMessage message = new MimeMessage(session);

         // Set From: header field of the header.
         message.setFrom(new InternetAddress(from));

         // Set To: header field of the header.
         message.addRecipient(Message.RecipientType.TO, new InternetAddress(to));

         // Set Subject: header field
         message.setSubject("["+cluster_name+"]: Lost_HeartBeat Alert");
       	 message.setContent("<h1>"+"LOST HEART BEAT NODES IN"+cluster_name+"</h1>", "text/html" );
         System.out.println(cluster_name);
       	 for(int i=0;i<host_names.size();i++)
         {
         // Send the actual HTML message, as big as you like
     
           //  message.setContent("<h2>"+host_names.get(i) +"</h2>", "text/html" );
             System.out.println(host_names.get(i) );
         }
       //  message.setContent("<h3> <a href="+url+"Ambari_Url" +"</a></h3>", "text/html" );
         System.out.println(url);
         // Send message
         try {
				Socket s = new Socket("100.65.238.25", 25);
				s.close();
         }
         catch(Exception e)
         {
        	 e.printStackTrace();
         }
         Transport.send(message);
         
         System.out.println("Sent message successfully....");
      }catch (MessagingException mex) {
         mex.printStackTrace();
      }
   }


}